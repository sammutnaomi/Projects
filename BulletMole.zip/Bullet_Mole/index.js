var menu = document.querySelector("#menu");
var start = document.querySelector("#start");
var title = document.querySelector("#title");
var gameover = document.querySelector("#gameover");
var gamewin = document.querySelector("#gamewin");
var gamemenu = document.querySelector("#gamemenu");
var camera = document.querySelector("#camera");
var replayOver = document.querySelector("#replayOver");
var replayWin = document.querySelector("#replayWin");
var scoreWin = document.querySelector("#scoreWin");
var scoreOver = document.querySelector("#scoreOver");
var playerGun = document.querySelector("#playerGun");

//Background Music
window.onload = function() {
  var backgroundMusic = document.getElementById('backgroundMusic');
  backgroundMusic.play();
}

//Start Menu
document.addEventListener("click", function () {
    menu.remove();
    start.remove();
    title.remove();
});

//Gun
var isClicked = false; // Variable to track the click state

camera.addEventListener('mousedown', function(){
  isClicked = true;
  playerGun.setAttribute('position', '0.009 -1 -1.087');
})

camera.addEventListener('mouseup', function(){
  isClicked = false;
  playerGun.setAttribute('position', '0.009 -1 -1.357');
});

//Score
var scoreText = document.getElementById('scoreText');
var score = 0;


//Enemy
//Enemy1
var enemy1 = document.getElementById('enemy1');

enemy1.addEventListener('click', function() {
  score += 100;
  scoreText.setAttribute('value', 'Score: ' + score);
    setTimeout(function(){
      if(enemy1.getAttribute('rotation', {x: 90, y: enemy1.getAttribute('rotation').y, z: enemy1.getAttribute('rotation').z})){
        enemy1.setAttribute('rotation', {x: 0, y: enemy1.getAttribute('rotation').y, z: enemy1.getAttribute('rotation').z});
      }
    }, 600)
});


//Enemy2
var enemy2 = document.getElementById('enemy2');

enemy2.addEventListener('click', function() {
  score += 100;
  scoreText.setAttribute('value', 'Score: ' + score);
  setTimeout(function(){
    if(enemy2.getAttribute('rotation', {x: 90, y: enemy2.getAttribute('rotation').y, z: enemy2.getAttribute('rotation').z})){
      enemy2.setAttribute('rotation', {x: 0, y: enemy2.getAttribute('rotation').y, z: enemy2.getAttribute('rotation').z});
    }
  }, 600)
});



//Ally
//Ally1
var ally1 = document.getElementById('ally1');

ally1.addEventListener('click', function() {
  score -= 100;
  scoreText.setAttribute('value', 'Score: ' + score);
  setTimeout(function(){
    if(ally1.getAttribute('rotation', {x: 90, y: ally1.getAttribute('rotation').y, z: ally1.getAttribute('rotation').z})){
      ally1.setAttribute('rotation', {x: 0, y: ally1.getAttribute('rotation').y, z: ally1.getAttribute('rotation').z});
    }
  }, 600)
});


//Ally2
var ally2 = document.getElementById('ally2');

ally2.addEventListener('click', function() {
  score -= 100;
  scoreText.setAttribute('value', 'Score: ' + score);
  setTimeout(function(){
    if(ally2.getAttribute('rotation', {x: 90, y: ally2.getAttribute('rotation').y, z: ally2.getAttribute('rotation').z})){
      ally2.setAttribute('rotation', {x: 0, y: ally2.getAttribute('rotation').y, z: ally2.getAttribute('rotation').z});
    }
  }, 600)
});


//Ally3
var ally3 = document.getElementById('ally3');

ally3.addEventListener('click', function() {
  score -= 100;
  scoreText.setAttribute('value', 'Score: ' + score);
  setTimeout(function(){
    if(ally3.getAttribute('rotation', {x: 90, y: ally3.getAttribute('rotation').y, z: ally3.getAttribute('rotation').z})){
      ally3.setAttribute('rotation', {x: 0, y: ally3.getAttribute('rotation').y, z: ally3.getAttribute('rotation').z});
    }
  }, 600)
});

///////////////////////////////////
function shuffle(array) {
  var currentIndex = array.length;
  var temporaryValue, randomIndex;

  while (currentIndex !== 0) {
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;

    temporaryValue = array[currentIndex];
    array[currentIndex] = array[randomIndex];
    array[randomIndex] = temporaryValue;
  }

  return array;
}

function updatePositions() {
  var positions = [
    { x: 0.763, y: 1.966, z: -1.885 },
    { x: 3.082, y: 1.127, z: -4.396 },
    { x: 6.157, y: 1.120, z: -5.159 },
    { x: -1.681, y: 1.131, z: -2.507 },
    { x: -4.399, y: 1.044, z: -3.234 }
  ];

  positions = shuffle(positions); // Randomly shuffle the positions array

  var boxes = document.querySelectorAll('a-entity[gltf-model]');
  for (var i = 0; i < boxes.length; i++) {
    var newPosition = positions[i];
    boxes[i].setAttribute('position', newPosition.x + ' ' + newPosition.y + ' ' + newPosition.z);
  }
}
setInterval(updatePositions, 1700);

/////////////////////
window.onload = function() {
  var timerText = document.getElementById('timer');
  var timerDuration = 90;
  var minutes, seconds;

  var timerInterval = setInterval(function() {
    minutes = Math.floor(timerDuration / 60);
    seconds = timerDuration % 60;

    timerText.setAttribute(
      "value",
      "Timer: " +
      minutes.toString().padStart(2, "0") +
      ":" +
      seconds.toString().padStart(2, "0")
    );

    timerDuration--;

    if (timerDuration <= 0) {
      clearInterval(timerInterval);
      timerText.setAttribute("value", "Timer: Times up!");
      if (score < 4999)
      {
        gameover.setAttribute('visible', 'true');
        camera.setAttribute('position', "1 1.2 6.826");
        scoreOver.setAttribute('value', 'Score: ' + score);
        gamewin.remove();
        replayOver.addEventListener('click', function(){
          window.location.reload();
        })
      }
      else{
        gamewin.setAttribute('visible', 'true');
        camera.setAttribute('position', "1 1.2 6.826");
        scoreWin.setAttribute('value', 'Score: ' + score);
        gameover.remove();
        gamemenu.remove();
        replayWin.addEventListener('click', function(){
          window.location.reload();
        })
      }
    }
  }, 1000);
};