using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class DontDestroyOnLoad : MonoBehaviour
{
    private static GameManager instance;

    private void Awake()
    {
        DontDestroyOnLoad(gameObject);
    }

    void Update()
    {
        if (SceneManager.GetActiveScene().name == "GameOver")
        {
            // Destroy the object when in the "GameOver" scene
            Destroy(this.gameObject);
        }

        if (SceneManager.GetActiveScene().name == "YouWin")
        {
            // Destroy the object when in the "GameOver" scene
            Destroy(this.gameObject);
        }
    }
}