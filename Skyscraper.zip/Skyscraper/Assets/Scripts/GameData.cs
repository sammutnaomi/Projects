using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameData : MonoBehaviour
{
    private static GameData instance;
    private int scoreValue = 0;

    public static GameData Instance
    {
        get
        {
            if (instance == null)
            {
                instance = FindObjectOfType<GameData>();

                if (instance == null)
                {
                    GameObject gameDataObject = new GameObject("GameData");
                    instance = gameDataObject.AddComponent<GameData>();
                    DontDestroyOnLoad(gameDataObject);
                }
            }

            return instance;
        }
    }

    public int ScoreValue
    {
        get { return scoreValue; }
        set { scoreValue = value; }
    }
}