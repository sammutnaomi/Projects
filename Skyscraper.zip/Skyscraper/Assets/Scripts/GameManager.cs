using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement; //added

public class GameManager : MonoBehaviour
{
    [SerializeField] private float timer;
    //________________________________
    public UI ui;
    public Angel angel;
    //________________________________

    void Start()
    {
        angel = FindObjectOfType<Angel>();
    }
    // Update is called once per frame
    void Update()
    {
        DisplayTimer(timer);
    }

    void DisplayTimer(float timerValue)
    {
        timer -= Time.deltaTime;
        timer = Mathf.Max(timer, 0);

        if (ui != null)
        {
            ui.TimerUI((int)timerValue);
        }

        if (SceneManager.GetActiveScene().name == "Level1")
        {
            if (timer <= 0)
            {
                SceneManager.LoadScene("Breakroom");
                timer = 15;
            }
        }
        else if (SceneManager.GetActiveScene().name == "Breakroom")
        {   
            angel.gameObject.SetActive(false);
            angel.speed = 0;
            if (timer <= 0)
            {
                SceneManager.LoadScene("Level2");
                timer = 60;
            }
        }
        else if (SceneManager.GetActiveScene().name == "Level2")
        {
            angel.gameObject.SetActive(true);
            angel.ModifyAngelSpeed(SpeedManager.amount);
            if (timer <= 0)
            {
                SceneManager.LoadScene("YouWin");
            }
        }
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("healthOrb") || collision.gameObject.CompareTag("coin"))
        {
            Destroy(collision.gameObject);
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("void"))
        {
             SceneManager.LoadScene("GameOver");
        }
    }
}
