using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; //added
using UnityEngine.SceneManagement; //added

public class Buttons : MonoBehaviour
{
    [SerializeField] List<Button> buttons;
    //___________________________________
    public Player player;
    public Angel angel;
    public Demons demons;
    //___________________________________

    // Start is called before the first frame update
    void Start()
    {
        player = FindObjectOfType<Player>();

        foreach (var button in buttons)
        {
            if (button.name == "Play") //button name
            {
                button.onClick.AddListener(Play); //method
            }
            else if (button.name == "HowToPlay")
            {
                button.onClick.AddListener(HowToPlay);
            }
            else if (button.name == "Quit")
            {
                button.onClick.AddListener(Quit);
            }
            else if (button.name == "Easy")
            {
                button.onClick.AddListener(Easy);
            }
            else if (button.name == "Medium")
            {
                button.onClick.AddListener(Medium);
            }
            else if (button.name == "Hard")
            {
                button.onClick.AddListener(Hard);
            }
            else if (button.name == "Back")
            {
                button.onClick.AddListener(Back);
            }
            else if (button.name == "Retry")
            {
                button.onClick.AddListener(Retry);
            }
            else if (button.name == "buyHealth") //For breakroom
            {
                button.onClick.AddListener(IncreasePlayerHealth);
            }
            else if (button.name == "buySpeed")
            {
                button.onClick.AddListener(IncreaseSpeed);
            }
            else if (button.name == "buyGunfire")
            {
                button.onClick.AddListener(DecreaseShootingCooldown);
            }
        }    
    }

    void Play()
    {
        SceneManager.LoadScene("Difficulty");
    }

    void HowToPlay()
    {
        SceneManager.LoadScene("HowToPlay");
    }

    void Quit()
    {
        #if UNITY_EDITOR
            UnityEditor.EditorApplication.isPlaying = false;
        #else
            Application.Quit();
        #endif
    }

    void Easy()
    {
        // Set the modified speed before loading the scene
        SpeedManager.amount = 1.0f;

        SceneManager.sceneLoaded += OnSceneLoaded;
        SceneManager.LoadScene("Level1");

        void OnSceneLoaded(Scene scene, LoadSceneMode mode)
        {
            Debug.Log("Scene loaded: " + scene.name);

            if (scene.name == "Level1" || scene.name == "Level2")
            {
                Debug.Log("Modifying angel speed in " + scene.name);

                Angel angel = FindObjectOfType<Angel>();
                if (angel != null)
                {
                    angel.ModifyAngelSpeed(SpeedManager.amount);
                }

                // Remove the event handler to avoid multiple calls
                SceneManager.sceneLoaded -= OnSceneLoaded;
            }
        }
    }

    void Medium()
    {
        // Set the modified speed before loading the scene
        SpeedManager.amount = 2.0f;

        SceneManager.sceneLoaded += OnSceneLoaded;
        SceneManager.LoadScene("Level1");

        void OnSceneLoaded(Scene scene, LoadSceneMode mode)
        {
            Debug.Log("Scene loaded: " + scene.name);

            if (scene.name == "Level1" || scene.name == "Level2")
            {
                Debug.Log("Modifying angel speed in " + scene.name);

                Angel angel = FindObjectOfType<Angel>();
                if (angel != null)
                {
                    angel.ModifyAngelSpeed(SpeedManager.amount);
                }

                // Remove the event handler to avoid multiple calls
                SceneManager.sceneLoaded -= OnSceneLoaded;
            }
        }
    }

    void Hard()
    {
        // Set the modified speed before loading the scene
        SpeedManager.amount = 5.0f;

        SceneManager.sceneLoaded += OnSceneLoaded;
        SceneManager.LoadScene("Level1");

        void OnSceneLoaded(Scene scene, LoadSceneMode mode)
        {
            Debug.Log("Scene loaded: " + scene.name);

            if (scene.name == "Level1" || scene.name == "Level2")
            {
                Debug.Log("Modifying angel speed in " + scene.name);

                Angel angel = FindObjectOfType<Angel>();
                if (angel != null)
                {
                    angel.ModifyAngelSpeed(SpeedManager.amount);
                }

                // Remove the event handler to avoid multiple calls
                SceneManager.sceneLoaded -= OnSceneLoaded;
            }
        }
    }

    void Retry()
    {
        SceneManager.LoadScene("Difficulty");
    }

    void Back()
    {
        SceneManager.LoadScene("Menu");
    }

    //For breakroom
    public void IncreasePlayerHealth()
    {
        if (player != null)
        {
            player.ModifyPlayerHealth(50);
        }
    }

    public void IncreaseSpeed()
    {
        if (player != null)
        {
            player.ModifySpeed(7);
        }
    }

    public void DecreaseShootingCooldown()
    {
        if (player != null)
        {
            player.ModifyShootingCooldown(0.1f);
        }
    }
}
