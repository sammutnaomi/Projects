using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "DemonsSO", menuName = "Custom/DemonsSO", order = 1)]
public class DemonsSO : ScriptableObject
{
    [Header("Demon Settings")]
    public float minShotValue = 2;
    public float maxShotValue = 5;
}
