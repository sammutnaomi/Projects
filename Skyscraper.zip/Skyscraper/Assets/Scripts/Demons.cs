using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Demons : MonoBehaviour
{
    [SerializeField] Transform[] waypoints;
    private int currentWaypointIndex = 0;
    [SerializeField] GameObject demonBulletPrefab;
    [SerializeField] private float speed;
    private bool isShooting = true;
    //_________________________________
    public UI ui;
    public DemonsSO demonsSO;
    //_________________________________

    // Start is called before the first frame update
    void Start()
    {
        ui = FindObjectOfType<UI>();
        StartCoroutine(Shoot());
    }

    // Update is called once per frame
    void Update()
    {
        if (currentWaypointIndex < waypoints.Length)
        {
            Move();
        }
    }

    void Move()
    {
        Vector2 spawnPos = waypoints[currentWaypointIndex].position;
        float move = speed * Time.deltaTime;
        transform.position = Vector2.MoveTowards(transform.position, spawnPos, move);

        if (Vector2.Distance(transform.position, spawnPos) < 0.1f)
        {
            currentWaypointIndex++;
        }
    }

    IEnumerator Shoot()
    {
        while (true)
        {
            if (isShooting)
            {
                yield return new WaitForSeconds(Random.Range(demonsSO.minShotValue, demonsSO.maxShotValue));
                GameObject demonBullet = Instantiate(demonBulletPrefab, transform.position, Quaternion.identity);

                if (demonBullet != null)
                {
                    Destroy(demonBullet, 2f);
                }
            }
            else
            {
                yield return null;
            }
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (GameData.Instance != null)  
        {
            if (other.CompareTag("playerBullet"))
            {
                GameData.Instance.ScoreValue++;
                
                // Assuming ui is a reference to your UI script
                if (ui != null) 
                {
                    ui.ScoreUI(GameData.Instance.ScoreValue);
                }

                //reset demon pos after shot
                currentWaypointIndex = 0;
                transform.position = waypoints[currentWaypointIndex].position;

                // Rest of your code...
            }
            else if (other.CompareTag("top"))
            {
                Debug.Log("Demons got you");
                SceneManager.LoadScene("GameOver");
            }
        }
    }
}
