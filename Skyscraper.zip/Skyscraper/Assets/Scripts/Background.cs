using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Background : MonoBehaviour
{
    float speed = 0.1f;
    private Vector3 startPos;

    private void Update()
    {
        MoveBackground();
    }

    private void MoveBackground()
    {
        transform.Translate(Vector3.left * speed * Time.deltaTime);
    }

    private void Start()
    {
        startPos = transform.position;
    }
}
