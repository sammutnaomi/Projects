using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    [SerializeField] float timer;
    [SerializeField] GameObject doorPrefab;
    private bool showDoor = false;
    //________________________________
    public UI ui; //reference to UI script
    //________________________________
    
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        DisplayTimer(timer);
        if (timer <= 0 && !showDoor)
        {
            SpawnDoor();
            showDoor = true;
        }
    }

    void SpawnDoor()
    {
        if (doorPrefab != null)
        {
            Instantiate(doorPrefab, transform.position, Quaternion.identity);
        }
    }

    void DisplayTimer(float timerValue)
    {
        timer -= Time.deltaTime;
        timer = Mathf.Max(timer, 0);

        if (ui != null)
        {
            ui.TimerUI((int)timerValue);
        }

        if (SceneManager.GetActiveScene().name == "Breakroom" && timer <= 0) //=
        {
            timer = 15;
        }
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
                                                                                                    //coins and healthOrbs touch void
        if (collision.gameObject.CompareTag("healthOrb") || collision.gameObject.CompareTag("coin") || collision.gameObject.CompareTag("void"))
        {
            Destroy(collision.gameObject);
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (!other.CompareTag("void"))
        {
            if (other.CompareTag("Player"))
            {
                SceneManager.LoadScene("Breakroom");
            }
        }
        else
        {
            SceneManager.LoadScene("GameOver");
        }

        if(other.CompareTag("playerBullet"))
        {
            Destroy(other.gameObject);
        }
    }
}
