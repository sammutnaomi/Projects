using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UI : MonoBehaviour
{
    [SerializeField] Text healthText;
    [SerializeField] Text timerText;
    [SerializeField] Text coinText;
    [SerializeField] Text scoreText;
    //______________________________
    
    public void HealthUI(int healthValue)
    {
        healthText.text = "Health: " + healthValue;
    }

    public void TimerUI(int timerValue)
    {
        timerText.text = "Timer: " + timerValue + "s";
    }

    public void CoinUI(int coinValue)
    {
        coinText.text = "Coin: " + coinValue;
    }

    public void ScoreUI(int scoreValue)
    {
        scoreText.text = "Score: " + scoreValue;
    }
}
