using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Buttons : MonoBehaviour
{
    public Player player;
    //___________________

    void Start()
    {
        // Attempt to find the Player script dynamically
        player = FindObjectOfType<Player>();
    }

    public void IncreasePlayerHealth()
    {
        if (player != null)
        {
            player.ModifyPlayerHealth(50);
        }
        else
        {
            Debug.Log("Player reference is null in Buttons script.");
        }
    }

    public void IncreaseSpeed()
    {
        if (player != null)
        {
            player.ModifySpeed(7);
        }
    }

    public void DecreaseShootingCooldown()
    {
        if (player != null)
        {
            player.ModifyShootingCooldown(0.1f);
        }
    }

    public void ChangeSceneTo(string sceneName)
    {
        SceneManager.LoadScene(sceneName);
    }

    public void Quit()
    {
        Application.Quit();
    }
}