using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Player : MonoBehaviour
{
    [SerializeField] int speed = 5;
    private const int maxHealth = 100;
    [SerializeField] int currentHealth; //to see health drop
    [SerializeField] GameObject playerBulletPrefab;
    private bool isShooting = true;
    [SerializeField] float shootingCooldown = 0.5f;
    private int coinValue = 0;
    [SerializeField] float jumpForce = 5;
    private bool onGround;
    //____________________________________
    public UI ui; //reference to UI script
    //____________________________________

    // Start is called before the first frame update
    void Start()
    {
        currentHealth = maxHealth;
    }

    // Update is called once per frame
    void Update()
    {
        HandleUserInput();
    }

    public void ModifySpeed(int amount)
    {
        Debug.Log("Speed increased");
        speed = amount;
    }

    public void ModifyPlayerHealth(int amount)
    {
        currentHealth = 100;
        Debug.Log("Reset health for next round + 50hp");
        currentHealth += amount;
        HealthUI();
    }

    public void ModifyShootingCooldown(float amount)
    {
        Debug.Log("Shooting cooldown reduced");
        shootingCooldown = amount;
    }

    void HandleUserInput()
    {
        //Moving
        float move = Input.GetAxis("Horizontal"); // A D / < > keys
        transform.Translate(Vector2.right * move * speed * Time.deltaTime);

        //Shooting
        if (Input.GetKeyDown(KeyCode.LeftShift) && isShooting)
        {
            Shoot();
        }

        //Jump
        if (Input.GetKeyDown(KeyCode.Space) && onGround)
        {
            Jump();
        }
    }

    void Shoot()
    {
        GameObject playerBullet = Instantiate(playerBulletPrefab, transform.position, transform.rotation); //create copies at position/rotation
        StartCoroutine(destroy_playerBullet(playerBullet, 1.5f)); //destory copies after 1.5 seconds
        StartCoroutine(ShootCooldown());
    }

    void Jump()
    {
        Rigidbody2D rb = GetComponent<Rigidbody2D>();
        rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
        rb.freezeRotation = true;
        onGround = false;
    }

    IEnumerator ShootCooldown()
    {
        isShooting = false;
        yield return new WaitForSeconds(shootingCooldown);
        isShooting = true;
    }

    IEnumerator destroy_playerBullet(GameObject playerBullet, float delay)
    {
        yield return new WaitForSeconds(delay);

        if (playerBullet != null)
        {
            Destroy(playerBullet);
        }
    }

    //player takes damage from demonBullet
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("demonBullet"))
        {
            currentHealth -= 5;
            Destroy(other.gameObject);
            HealthUI();

            //checks for death
            if (currentHealth == 0)
            {
                SceneManager.LoadScene("GameOver");
                Die();
            }
        }

        if (other.CompareTag("void"))
        {
            Debug.Log("You fell");
            SceneManager.LoadScene("GameOver");
        }
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("healthOrb"))
        {
            GainHealth(10); //gain +10 health to currentHealth
            Destroy(collision.gameObject);
        }

        if (collision.gameObject.CompareTag("coin"))
        {
            coinValue += 5;
            Destroy(collision.gameObject);
            ui.CoinUI(coinValue);
        }

        if (collision.gameObject.CompareTag("tower"))
        {
            onGround = true;
            Rigidbody2D rb = GetComponent<Rigidbody2D>();
            rb.freezeRotation = false;
        }
    }

    void GainHealth(int amount)
    {
        currentHealth = Mathf.Min(currentHealth + amount, maxHealth);
        HealthUI(); // Update the UI after gaining health
    }

    void HealthUI() //display current player health in UI
    {
        ui.HealthUI(currentHealth);
    }

    void Die()
    {
        Debug.Log("Player has died");
    }
}
