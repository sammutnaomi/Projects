using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Angel : MonoBehaviour
{
    [SerializeField] private Transform[] waypoints;
    private int currentWaypointIndex = 0;
    private float speed = 2.5f;
    //for looping
    private float generatedWaitTime;
    [SerializeField] float minWaitTime;
    [SerializeField] float maxWaitTime;
    private float elapsedTime;
    //for dropping
    [SerializeField] GameObject healthOrbPrefab;
    [SerializeField] GameObject coinPrefab;
    private bool dropOrb = true;
    private bool dropCoin = true;
    [SerializeField] float minDropTime;
    [SerializeField] float maxDropTime;
    //________________________________

    // Start is called before the first frame update
    void Start()
    {
        WaitTime();
        StartCoroutine(Orb());
        StartCoroutine(Coin());
    }

    // Update is called once per frame
    void Update()
    {
        if (currentWaypointIndex < waypoints.Length)
        {
            Move();
        }
        else
        {
            if (elapsedTime >= generatedWaitTime)
            {
                currentWaypointIndex = 0;
                WaitTime();
                elapsedTime = 0f;
            }
            else
            {
                elapsedTime += Time.deltaTime;
            }
        }
    }

    IEnumerator Orb()
    {
        while (true)
        {
            if (dropOrb)
            {
                yield return new WaitForSeconds(Random.Range(minDropTime, maxDropTime));
                GameObject healthOrb = Instantiate(healthOrbPrefab, transform.position, Quaternion.identity);
            }
            else
            {
                yield return null;
            }
        }
    }

    IEnumerator Coin()
    {
        while (true)
        {
            if (dropCoin)
            {
                yield return new WaitForSeconds(Random.Range(minDropTime, maxDropTime));
                GameObject coin = Instantiate(coinPrefab, transform.position, Quaternion.identity);
            }
            else
            {
                yield return null;
            }
        }
    }

    void Move()
    {
        Vector2 spawnPos = waypoints[currentWaypointIndex].position;
        float move = speed * Time.deltaTime;
        transform.position = Vector2.MoveTowards(transform.position, spawnPos, move);

        if (Vector2.Distance(transform.position, spawnPos) < 0.1f)
        {
            currentWaypointIndex++;
        }
    }

    void WaitTime()
    {
        generatedWaitTime = Random.Range(minWaitTime, maxWaitTime);
    }
}
