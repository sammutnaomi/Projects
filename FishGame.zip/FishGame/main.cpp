#include "raylib.h"
#include <cmath>
#include <vector>

//------------------------------------------------------------------------------------
// Program main entry point
//------------------------------------------------------------------------------------

struct Fish {
    Vector2 position;
    Vector2 speed;
    float radius;
    int health;
    float fishScale;
    float spawnTime;
    Texture2D textureLeft;
    Texture2D textureRight;
};

void UpdateAndDrawFish(std::vector<Fish>& allFishes, const Rectangle& fishArea) {
    auto fishIter = allFishes.begin();

    // Iterate through all fish in the vector
    while (fishIter != allFishes.end()) 
    {
        //track the current fish to see if it has been removed because of collision
        bool fishRemoved = false;
        // Iterator for nested loop to check for collisions with other fish
        auto otherFishIter = allFishes.begin();

        // Check collisions
        while (otherFishIter != allFishes.end()) {
            // Avoid self-collision by ensuring the fish being checked is not the same as the current fish
            if (fishIter != otherFishIter) {
                // Calculate the distance between the current fish and other fish
                float dx = fishIter->position.x - otherFishIter->position.x;
                float dy = fishIter->position.y - otherFishIter->position.y;
                float distance = sqrt(dx * dx + dy * dy);

                // Minimum distance for collision to occur
                float minDistance = fishIter->radius + otherFishIter->radius;

                // Check for collision
                if (distance < minDistance) {
                    // at fish collision, remove the other fish
                    otherFishIter = allFishes.erase(otherFishIter);
                    fishRemoved = true;
                    break;
                }
            }
            ++otherFishIter;
        }

        // If no collision occurred, update fish position and handle boundary conditions
        if (!fishRemoved)
        {
            fishIter->position.x += fishIter->speed.x * GetFrameTime();
            fishIter->position.y += fishIter->speed.y * GetFrameTime();

            // Boundary check and reflection for x-axis
            if (fishIter->position.x < fishArea.x + fishIter->radius) {
                fishIter->position.x = fishArea.x + fishIter->radius;
                fishIter->speed.x *= -1;
            } else if (fishIter->position.x > fishArea.x + fishArea.width - fishIter->radius) {
                fishIter->position.x = fishArea.x + fishArea.width - fishIter->radius;
                fishIter->speed.x *= -1;
            }

            // Boundary check and reflection for y-axis
            if (fishIter->position.y < fishArea.y + fishIter->radius) {
                fishIter->position.y = fishArea.y + fishIter->radius;
                fishIter->speed.y *= -1;
            } else if (fishIter->position.y > fishArea.y + fishArea.height - fishIter->radius) {
                fishIter->position.y = fishArea.y + fishArea.height - fishIter->radius;
                fishIter->speed.y *= -1;
            }

            // Individual elapsed time for each fish
            float individualElapsedTime = GetTime() - fishIter->spawnTime;

            // Increase fish scale after 2 seconds
            if (individualElapsedTime >= 2.0f) {
                float maxFishScale = 0.6f;
                float minFishScale = 0.3f;
                float growthDuration = 2.0f;  // Total time for growth from 0.3 to 0.6
                float growthRate = (maxFishScale - minFishScale) / growthDuration;
                    
                // Adjust fish scale based on elapsed time
                fishIter->fishScale = std::min(maxFishScale, minFishScale + growthRate * (individualElapsedTime - 2.0f));
            } 
            else 
            {
                // Initial fish scale
                fishIter->fishScale = 0.3f;
            }

            // Select the appropriate texture based on fish direction
            Texture2D currentTexture = (fishIter->speed.x < 0) ? fishIter->textureLeft : fishIter->textureRight;

            // Draw the fish with the updated properties
            DrawTextureEx(currentTexture, { fishIter->position.x, fishIter->position.y }, 0.0f, fishIter->fishScale, WHITE);

            // Move to the next fish in the vector
            ++fishIter;
        }
    }
}

int main(void)
{
    // Initialization
    //--------------------------------------------------------------------------------------
    const int screenWidth = 990;
    const int screenHeight = 450;

    InitWindow(screenWidth, screenHeight, "raylib [core] example - basic window");
    SetTargetFPS(60);   // 60 frames-per-second
    InitAudioDevice();  // for audio

    int money = 999;

    //showFish
    bool showBlue = false;
    bool showOrange = false;
    bool showGreen = false;
    bool showBlack = false;

    //Decors
    bool showD1 = false;
    bool showD2 = false;
    bool showD3 = false;
    bool showD4 = false;

    bool exitGame = false;

    // Load textures
    //--------------------------------------------------------------------------------------
    Texture2D background = LoadTexture("images/BACKGROUND.png");        //background_image
    Texture2D home_button = LoadTexture("images/HOME.png");             //home_button_image
    Texture2D trash_all_button = LoadTexture("images/TRASH_ALL.png");   //trash_all_button_image
    Texture2D chest_button = LoadTexture("images/CHEST.png");           //chest_button_image
    Texture2D buyBlue_button = LoadTexture("images/buyBlue.png");       //buyBlue_button_image
    Texture2D buyOrange_button = LoadTexture("images/buyOrange.png");   //buyOrange_button_image
    Texture2D buyGreen_button = LoadTexture("images/buyGreen.png");     //buyGreen_button_image
    Texture2D buyBlack_button = LoadTexture("images/buyBlack.png");     //buyBlack_button_image
    Texture2D buyD1_button = LoadTexture("images/buyD1.png");           //buyD1_button_image
    Texture2D buyD2_button = LoadTexture("images/buyD2.png");           //buyD2_button_image
    Texture2D buyD3_button = LoadTexture("images/buyD3.png");           //buyD3_button_image
    Texture2D buyD4_button = LoadTexture("images/buyD4.png");           //buyD4_button_image
    Texture2D decor1 = LoadTexture("images/decor1.png");                //decor1_image
    Texture2D decor2 = LoadTexture("images/decor2.png");                //decor2_image
    Texture2D decor3 = LoadTexture("images/decor3.png");                //decor3_image
    Texture2D decor4 = LoadTexture("images/decor4.png");                //decor4_image
    Texture2D leftBlue = LoadTexture("images/leftBlue.png");            //leftBlue_image
    Texture2D rightBlue = LoadTexture("images/rightBlue.png");          //rightBlue_image
    Texture2D leftOrange = LoadTexture("images/leftOrange.png");        //leftOrange_image
    Texture2D rightOrange = LoadTexture("images/rightOrange.png");      //rightOrange_image
    Texture2D leftGreen = LoadTexture("images/leftGreen.png");          //leftGreen_image
    Texture2D rightGreen = LoadTexture("images/rightGreen.png");        //rightGreen_image
    Texture2D leftBlack = LoadTexture("images/leftBlack.png");          //leftBlack_image
    Texture2D rightBlack = LoadTexture("images/rightBlack.png");        //rightBlack_image

    // Load sounds
    //--------------------------------------------------------------------------------------
    Sound BG_sound = LoadSound("audio/BG_sound.wav");
    Sound buy_sound = LoadSound("audio/buy.wav");
    Sound decor_sound = LoadSound("audio/decor.wav");
    Sound wood_sound = LoadSound("audio/wood.wav");
    
    PlaySound(BG_sound);    //background noise

    //vector
    std::vector<Fish> allFishes; //stores all fish
    //______________________________________________________________________

    // Main game loop - run this when window open...
    while (!WindowShouldClose())    // Detect window close button or ESC key
    {
        // Update
        //----------------------------------------------------------------------------------
        // TODO: Update your variables here
        //----------------------------------------------------------------------------------

        // Draw
        //----------------------------------------------------------------------------------
                          //    X  Y
        DrawTexture(background, 0, 0, WHITE);            //background_location
        DrawTexture(home_button, 50, 320, WHITE);        //home_button_location
        DrawTexture(trash_all_button, 170, 332, WHITE);  //trash_all_button_location
        DrawTexture(chest_button, 600, 279, WHITE);      //chest_button_location
        DrawTexture(buyBlue_button, -5, 80, WHITE);      //buyBlue_button_location
        DrawTexture(buyOrange_button, -5, 160, WHITE);   //buyOrange_button_location
        DrawTexture(buyGreen_button, -5, 240, WHITE);    //buyGreen_button_location
        DrawTexture(buyBlack_button, -5, 320, WHITE);    //buyBlack_button_location
        DrawTexture(buyD1_button, 880, 80, WHITE);       //buyD1_button_location
        DrawTexture(buyD2_button, 880, 160, WHITE);      //buyD2_button_location
        DrawTexture(buyD3_button, 880, 240, WHITE);      //buyD3_button_location
        DrawTexture(buyD4_button, 880, 320, WHITE);      //buyD4_button_location
        
        BeginDrawing();
            //fish screen bounds
            Rectangle fishArea = { 105.0f, 80.0f, static_cast<float>(690), static_cast<float>(370) };

            //                                      DECORS
            //--------------------------------------------------------------------------------------
            //_____________showD1______________
            Rectangle D1ButtonRect = { 900.0f, 80.0f, static_cast<float>(90), static_cast<float>(buyD4_button.height) };

            if (CheckCollisionPointRec(GetMousePosition(), D1ButtonRect) && IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                PlaySound(decor_sound);
                showD1= true; //only show d1
                showD2= false;
                showD3= false;
                showD4= false;
            }
            if (showD1) {
                DrawTextureEx(decor1, {90.0f, 50.0f}, 1.0f, 1.0f, CLITERAL(Color){ 255, 255, 255, 180 }); //show image + opactiy
            }

            //_____________showD2______________
            Rectangle D2ButtonRect = { 900.0f, 160.0f, static_cast<float>(90), static_cast<float>(buyD4_button.height) };

            if (CheckCollisionPointRec(GetMousePosition(), D2ButtonRect) && IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                PlaySound(decor_sound);
                showD1= false;
                showD2= true; //only show d2
                showD3= false;
                showD4= false;
            }
            if (showD2) {
                DrawTextureEx(decor2, {170.0f, 50.0f}, 0.0f, 0.8f, CLITERAL(Color){ 255, 255, 255, 180 });
            }

            //_____________showD3______________
            Rectangle D3ButtonRect = { 900.0f, 240.0f, static_cast<float>(90), static_cast<float>(buyD4_button.height) };

            if (CheckCollisionPointRec(GetMousePosition(), D3ButtonRect) && IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                PlaySound(decor_sound);
                showD1= false;
                showD2= false;
                showD3= true; //only show d3
                showD4= false;
            }
            if (showD3) {
                DrawTextureEx(decor3, {120.0f, 50.0f}, 0.0f, 0.9f, CLITERAL(Color){ 255, 255, 255, 180});
            }

            //_____________showD4______________
            Rectangle D4ButtonRect = { 900.0f, 320.0f, static_cast<float>(90), static_cast<float>(buyD4_button.height) };

            if (CheckCollisionPointRec(GetMousePosition(), D4ButtonRect) && IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                PlaySound(decor_sound);
                showD1= false;
                showD2= false;
                showD3= false;
                showD4= true; //only show d4
            }
            if (showD4) {
                DrawTextureEx(decor4, {170.0f, 100.0f}, 0.0f, 0.8f, CLITERAL(Color){ 255, 255, 255, 180 });
            }

            //                                      FISHIES
            //--------------------------------------------------------------------------------------
            //_____________showBlue______________
            //                          (X, Y) position,          box width,                      box height.
            Rectangle BlueButtonRect = { -1.0f, 80.0f, static_cast<float>(90), static_cast<float>(buyD4_button.height) };

            if (CheckCollisionPointRec(GetMousePosition(), BlueButtonRect) && IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                showBlue = true;

                if (money >= 15) {
                    money -= 15;
                    PlaySound(buy_sound);

                    Fish blueFish;
                    blueFish.position = { static_cast<float>(GetRandomValue(105, 795)), static_cast<float>(GetRandomValue(80, 450)) };
                    blueFish.speed = { 50.0f, 50.0f };
                    blueFish.radius = 20.0f;
                    blueFish.textureLeft = leftBlue;
                    blueFish.textureRight = rightBlue;
                    blueFish.health = 1;

                    blueFish.fishScale = 0.3f;
                    blueFish.spawnTime = GetTime();

                    allFishes.push_back(blueFish);
                }

            }
            if (showBlue) {
                UpdateAndDrawFish(allFishes, fishArea);
            }

            //_____________showOrange______________
            Rectangle OrangeButtonRect = { -1.0f, 160.0f, static_cast<float>(90), static_cast<float>(buyD4_button.height) };

            if (CheckCollisionPointRec(GetMousePosition(), OrangeButtonRect) && IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                showOrange = true;

                if (money >= 20) {
                    money -= 20;
                    PlaySound(buy_sound);

                    Fish orangeFish;
                    orangeFish.position = { static_cast<float>(GetRandomValue(105, 795)), static_cast<float>(GetRandomValue(80, 450)) };
                    orangeFish.speed = { 50.0f, 50.0f };
                    orangeFish.radius = 20.0f;
                    orangeFish.textureLeft = leftOrange;
                    orangeFish.textureRight = rightOrange;
                    orangeFish.health = 1;

                    orangeFish.fishScale = 0.3f;
                    orangeFish.spawnTime = GetTime();

                    allFishes.push_back(orangeFish);
                }
            }
            if (showOrange) {
                UpdateAndDrawFish(allFishes, fishArea);
            }

            //_____________showGreen______________
            Rectangle GreenButtonRect = { -1.0f, 240.0f, static_cast<float>(90), static_cast<float>(buyD4_button.height) };

            if (CheckCollisionPointRec(GetMousePosition(), GreenButtonRect) && IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                showGreen = true;

                if (money >= 30) {
                    money -= 30;
                    PlaySound(buy_sound);

                    Fish greenFish;
                    greenFish.position = { static_cast<float>(GetRandomValue(105, 795)), static_cast<float>(GetRandomValue(80, 450)) };
                    greenFish.speed = { 50.0f, 50.0f };
                    greenFish.radius = 20.0f;
                    greenFish.textureLeft = leftGreen;
                    greenFish.textureRight = rightGreen;
                    greenFish.health = 1;

                    greenFish.fishScale = 0.3f;
                    greenFish.spawnTime = GetTime();

                    allFishes.push_back(greenFish);
                }
            }

            if (showGreen) {
                UpdateAndDrawFish(allFishes, fishArea);
            }

            
            //_____________showBlack______________
            Rectangle BlackButtonRect = { 0.0f, 320.0f, static_cast<float>(90), static_cast<float>(buyD4_button.height) };

            if (CheckCollisionPointRec(GetMousePosition(), BlackButtonRect) && IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                showBlack = true;

                if (money >= 40) {
                    money -= 40;
                    PlaySound(buy_sound);

                    Fish blackFish;
                    blackFish.position = { static_cast<float>(GetRandomValue(105, 795)), static_cast<float>(GetRandomValue(80, 450)) };
                    blackFish.speed = { 50.0f, 50.0f };
                    blackFish.radius = 20.0f;
                    blackFish.textureLeft = leftBlack;
                    blackFish.textureRight = rightBlack;
                    blackFish.health = 1;

                    blackFish.fishScale = 0.3f;
                    blackFish.spawnTime = GetTime();

                    allFishes.push_back(blackFish);
                }
            }

            if (showBlack) {
                UpdateAndDrawFish(allFishes, fishArea);
            }
            
            // SIGN_BUTTONS
            //--------------------------------------------------------------------------------------
            //___________Trash___________
            Rectangle trashButtonRect = { 265.0f, 332.0f, static_cast<float>(95), static_cast<float>(trash_all_button.height) };

            if (CheckCollisionPointRec(GetMousePosition(), trashButtonRect) && IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                PlaySound(wood_sound);
                showBlue = false;
                showOrange = false;
                showGreen = false;
                showBlack = false;
                allFishes.clear(); //clear vector
            }
            //_____________Home______________
            Rectangle homeButtonRect = { 155.0f, 335.0f, static_cast<float>(95), static_cast<float>(home_button.height) };

            if (CheckCollisionPointRec(GetMousePosition(), homeButtonRect) && IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                PlaySound(wood_sound);
                exitGame = true;
            }

            // Draw text
            //--------------------------------------------------------------------------------------
                                          //    X    Y  font colour
            DrawText(TextFormat("$%d", money), 775, 380, 20, WHITE);     //money

        EndDrawing();
        
        if (exitGame) {
            break;  // Exit
        }
    }

    // De-Initialization
    //--------------------------------------------------------------------------------------
    UnloadTexture(background);
    UnloadTexture(home_button);
    UnloadTexture(trash_all_button);
    UnloadTexture(chest_button);
    UnloadTexture(buyBlue_button);
    UnloadTexture(buyOrange_button);
    UnloadTexture(buyGreen_button);
    UnloadTexture(buyBlack_button);
    UnloadTexture(buyD1_button);
    UnloadTexture(buyD2_button);
    UnloadTexture(buyD3_button);
    UnloadTexture(buyD4_button);
    UnloadTexture(decor1);
    UnloadTexture(decor2);
    UnloadTexture(decor3);
    UnloadTexture(decor4);
    UnloadTexture(leftBlue);
    UnloadTexture(rightBlue);
    UnloadTexture(leftOrange);
    UnloadTexture(rightOrange);
    UnloadTexture(leftGreen);
    UnloadTexture(rightGreen);
    UnloadTexture(leftBlack);
    UnloadTexture(rightBlack);
    UnloadSound(BG_sound); //sounds
    UnloadSound(buy_sound);
    UnloadSound(decor_sound);
    UnloadSound(wood_sound);

    //--------------------------------------------------------------------------------------
    CloseAudioDevice();
    CloseWindow();
    
    return 0;
}